# Bank Management System
**Course:** 01CE0308 – Advanced Java Technology  
**Student:** G. Abhilash | **Enrollment:** 92500120022

## Description
Academic Java web application for customer records, account viewing and deposit/withdrawal transaction demonstrations.

## Technologies
Java 17, Maven, Spring Boot 3 / Spring MVC, JSP, JSTL, EL, Spring Data JPA, Hibernate, MySQL, Tomcat 10.1, HTML and CSS.

## Features
- Login/logout and session tracking
- Customer CRUD
- Account listing
- Deposit and withdrawal with balance checks
- Transaction history
- Server-side validation and JSP/JSTL dynamic views

## Demo login
Username `admin`, password `admin123`. Hard-coded for classroom demonstration only; not production authentication.

## Database setup
Start MySQL/XAMPP and execute `database/schema.sql` in phpMyAdmin. Defaults are database `bank_management`, user `root`, empty password. Override using `DB_URL`, `DB_USER`, `DB_PASSWORD`.

## Run
Install JDK 17 and Maven 3.8+.
```bash
mvn clean package
mvn spring-boot:run
```
Open `http://localhost:8080/`. For external deployment, deploy `target/bank-management-system.war` to Tomcat 10.1.

## Screenshots
Capture genuine screenshots from your running system and add them to `docs/screenshots/`: login, dashboard, customer CRUD, accounts, transactions, database tables and logout.

## GitHub repository
Replace this line with the actual repository URL after pushing: **[ADD GITHUB URL]**

## Deployed application
Replace this line with the actual tested public URL after deployment: **[ADD DEPLOYED URL]**

## Limitations / evaluation checklist
This is a starter implementation and must be built and tested locally. Account creation/editing is not included (accounts are listed); authentication uses a demo hard-coded login. Do not use real financial data. Add screenshots, test all routes and replace link placeholders before submission.
