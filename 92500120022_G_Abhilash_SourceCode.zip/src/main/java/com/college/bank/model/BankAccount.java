package com.college.bank.model;
import jakarta.persistence.*; import java.math.BigDecimal;
@Entity @Table(name="accounts")
public class BankAccount {
 @Id @Column(name="account_no") private Long accountNo;
 @ManyToOne @JoinColumn(name="customer_id",nullable=false) private Customer customer;
 @Column(name="account_type") private String accountType;
 @Column(precision=12,scale=2) private BigDecimal balance=BigDecimal.ZERO;
 private String branch;
 public Long getAccountNo(){return accountNo;} public Customer getCustomer(){return customer;}
 public String getAccountType(){return accountType;} public BigDecimal getBalance(){return balance;}
 public void setBalance(BigDecimal b){balance=b;} public String getBranch(){return branch;}
}