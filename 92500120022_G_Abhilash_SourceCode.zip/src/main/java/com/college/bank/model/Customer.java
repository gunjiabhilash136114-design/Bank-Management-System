package com.college.bank.model;
import jakarta.persistence.*; import jakarta.validation.constraints.*;
@Entity @Table(name="customers")
public class Customer {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) @Column(name="customer_id") private Integer customerId;
 @NotBlank @Column(name="customer_name",nullable=false) private String customerName;
 @Pattern(regexp="^[0-9]{10}$",message="Enter exactly 10 digits") private String phone;
 @Email private String email; private String address;
 public Integer getCustomerId(){return customerId;} public void setCustomerId(Integer x){customerId=x;}
 public String getCustomerName(){return customerName;} public void setCustomerName(String x){customerName=x;}
 public String getPhone(){return phone;} public void setPhone(String x){phone=x;}
 public String getEmail(){return email;} public void setEmail(String x){email=x;}
 public String getAddress(){return address;} public void setAddress(String x){address=x;}
}