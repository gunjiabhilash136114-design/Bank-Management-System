package com.college.bank.model;
import jakarta.persistence.*; import java.math.BigDecimal; import java.time.LocalDateTime;
@Entity @Table(name="transactions")
public class BankTransaction {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) @Column(name="transaction_id") private Integer transactionId;
 @ManyToOne @JoinColumn(name="account_no") private BankAccount account;
 @Column(name="transaction_type") private String transactionType;
 private BigDecimal amount; @Column(name="transaction_date") private LocalDateTime transactionDate=LocalDateTime.now();
 public Integer getTransactionId(){return transactionId;} public BankAccount getAccount(){return account;}
 public String getTransactionType(){return transactionType;} public BigDecimal getAmount(){return amount;}
 public LocalDateTime getTransactionDate(){return transactionDate;}
 public void setAccount(BankAccount a){account=a;} public void setTransactionType(String t){transactionType=t;} public void setAmount(BigDecimal a){amount=a;}
}