package com.college.bank.repo;
import com.college.bank.model.BankAccount; import org.springframework.data.jpa.repository.JpaRepository;
public interface AccountRepository extends JpaRepository<BankAccount,Long>{}