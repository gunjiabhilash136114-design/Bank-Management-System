package com.college.bank.repo;
import com.college.bank.model.Customer; import org.springframework.data.jpa.repository.JpaRepository;
public interface CustomerRepository extends JpaRepository<Customer,Integer>{}