package com.college.bank.repo;
import com.college.bank.model.BankTransaction; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface TransactionRepository extends JpaRepository<BankTransaction,Integer>{List<BankTransaction> findTop50ByOrderByTransactionDateDesc();}