package com.college.bank.controller;
import jakarta.servlet.http.*; import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.web.bind.annotation.*;
@Controller public class AuthController {
 @GetMapping({"/","/login"}) public String login(){return "login";}
 @PostMapping("/login") public String check(@RequestParam String username,@RequestParam String password,HttpServletRequest r,Model m){
 if("admin".equals(username)&&"admin123".equals(password)){r.getSession(true).setAttribute("user",username);return "redirect:/dashboard";}
 m.addAttribute("error","Invalid username or password");return "login";}
 @GetMapping("/logout") public String logout(HttpServletRequest r){HttpSession s=r.getSession(false);if(s!=null)s.invalidate();return "redirect:/login";}
}