package com.college.bank.controller;
import com.college.bank.model.Customer; import com.college.bank.service.BankService; import jakarta.servlet.http.*; import jakarta.validation.Valid;
import org.springframework.stereotype.Controller; import org.springframework.ui.Model; import org.springframework.validation.BindingResult; import org.springframework.web.bind.annotation.*; import java.math.BigDecimal;
@Controller public class BankController {
 private final BankService s; public BankController(BankService s){this.s=s;}
 private boolean auth(HttpServletRequest r){HttpSession x=r.getSession(false);return x!=null&&x.getAttribute("user")!=null;}
 @GetMapping("/dashboard") public String dash(Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";m.addAttribute("count",s.customers().size());return "dashboard";}
 @GetMapping("/customers") public String list(Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";m.addAttribute("customers",s.customers());return "customers";}
 @GetMapping("/customers/new") public String form(Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";m.addAttribute("customer",new Customer());return "customer-form";}
 @PostMapping("/customers/save") public String save(@Valid @ModelAttribute Customer c,BindingResult b,HttpServletRequest r){if(!auth(r))return "redirect:/login";if(b.hasErrors())return "customer-form";s.save(c);return "redirect:/customers";}
 @GetMapping("/customers/edit/{id}") public String edit(@PathVariable int id,Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";m.addAttribute("customer",s.customer(id));return "customer-form";}
 @PostMapping("/customers/delete/{id}") public String delete(@PathVariable int id,HttpServletRequest r){if(!auth(r))return "redirect:/login";try{s.delete(id);}catch(Exception e){return "redirect:/customers?error=linked";}return "redirect:/customers";}
 @GetMapping("/accounts") public String accounts(Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";m.addAttribute("accounts",s.accounts());return "accounts";}
 @GetMapping("/transactions") public String tx(Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";m.addAttribute("accounts",s.accounts());m.addAttribute("transactions",s.transactions());return "transactions";}
 @PostMapping("/transactions") public String transact(@RequestParam Long accountNo,@RequestParam String type,@RequestParam BigDecimal amount,Model m,HttpServletRequest r){if(!auth(r))return "redirect:/login";try{s.transact(accountNo,type,amount);return "redirect:/transactions?success";}catch(Exception e){m.addAttribute("error",e.getMessage());m.addAttribute("accounts",s.accounts());m.addAttribute("transactions",s.transactions());return "transactions";}}
}