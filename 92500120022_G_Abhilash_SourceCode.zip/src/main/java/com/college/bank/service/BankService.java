package com.college.bank.service;
import com.college.bank.model.*; import com.college.bank.repo.*; import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional; import java.math.BigDecimal; import java.util.List;
@Service public class BankService {
 private final CustomerRepository cr; private final AccountRepository ar; private final TransactionRepository tr;
 public BankService(CustomerRepository c,AccountRepository a,TransactionRepository t){cr=c;ar=a;tr=t;}
 public List<Customer> customers(){return cr.findAll();} public Customer customer(int id){return cr.findById(id).orElseThrow();}
 public void save(Customer c){cr.save(c);} public void delete(int id){cr.deleteById(id);}
 public List<BankAccount> accounts(){return ar.findAll();} public List<BankTransaction> transactions(){return tr.findTop50ByOrderByTransactionDateDesc();}
 @Transactional public void transact(Long no,String type,BigDecimal amount){
  if(amount==null||amount.signum()<=0)throw new IllegalArgumentException("Amount must be greater than zero");
  BankAccount a=ar.findById(no).orElseThrow(()->new IllegalArgumentException("Account not found"));
  if("WITHDRAWAL".equals(type)){if(a.getBalance().compareTo(amount)<0)throw new IllegalArgumentException("Insufficient balance");a.setBalance(a.getBalance().subtract(amount));}
  else if("DEPOSIT".equals(type))a.setBalance(a.getBalance().add(amount)); else throw new IllegalArgumentException("Invalid transaction type");
  ar.save(a); BankTransaction t=new BankTransaction();t.setAccount(a);t.setTransactionType(type);t.setAmount(amount);tr.save(t);
 }
}