CREATE DATABASE IF NOT EXISTS bank_management; USE bank_management;
CREATE TABLE IF NOT EXISTS customers(customer_id INT PRIMARY KEY AUTO_INCREMENT,customer_name VARCHAR(100) NOT NULL,phone VARCHAR(15),email VARCHAR(100),address VARCHAR(200));
CREATE TABLE IF NOT EXISTS accounts(account_no BIGINT PRIMARY KEY,customer_id INT NOT NULL,account_type VARCHAR(20),balance DECIMAL(12,2) DEFAULT 0,branch VARCHAR(80),FOREIGN KEY(customer_id) REFERENCES customers(customer_id));
CREATE TABLE IF NOT EXISTS transactions(transaction_id INT PRIMARY KEY AUTO_INCREMENT,account_no BIGINT NOT NULL,transaction_type VARCHAR(20) NOT NULL,amount DECIMAL(12,2) NOT NULL,transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(account_no) REFERENCES accounts(account_no));
