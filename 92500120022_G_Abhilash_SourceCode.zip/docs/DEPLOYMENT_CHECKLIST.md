1. Install Java 17, Maven and Tomcat 10.1.
2. Create DB using database/schema.sql.
3. Configure DB_URL, DB_USER and DB_PASSWORD.
4. Run mvn clean package.
5. Deploy WAR to Tomcat and test login, CRUD and transactions.
6. Capture screenshots.
7. Push source to GitHub and replace README link placeholders.
8. Test public deployment URL from another device/browser.
